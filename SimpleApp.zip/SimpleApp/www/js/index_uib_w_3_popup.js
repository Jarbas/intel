function uib_w_3_popup_controller($scope, $ionicPopup) {

    // A confirm dialog
    $scope.show = function () {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Testando plugin Device',
            template: 'Dados do disposito: <br/> ' +
                window.device.platform + '<br/>' +
                window.device.mode,
            // customizando o botão da janela popup
            buttons: [
                {
                    text: 'OK',
                    type: 'button-positive',
                    onTap: function (e) {
                        // fechando a janela popup
                        return $scope.close;
                    }
                }
            ]
        });
        confirmPopup.then(function (res) {
            if (res) {
                console.log('You are sure');
            } else {
                console.log('You are not sure');
            }
        });
    };

};