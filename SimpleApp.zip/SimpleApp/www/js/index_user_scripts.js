/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
        
        /* button  #btncontatos */
    $(document).on("click", "#btncontatos", function(evt)
    {
        var options = new ContactFindOptions();
        options.filter = "";
        options.multiple = true;
        var fields = ["displayName", "name"];
        navigator.contacts.find(fields, onSucessoContatos, onErroContatos, options);
    });
     
    /** img #imgfoto */
    $(document).on("click", "#imgfoto", function(evt) 
    {
        alert("teste");
        navigator.camera.getPicture(
            onSucessoFoto,
            onErroFoto,
            {
                quality: 50,
                destinationType:    Camera.DestinationType.DATA_URL
            }
        );       
    });
     /* button  #btndialogos */
    $(document).on("click", "#btndialogos", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#sbdialogos"); 
         return false;
    });
    
        /* button  #btnvoltar */
    $(document).on("click", "#btnvoltar", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_32_23"); 
         return false;
    });
    
        /* button  #btnalerta */
    $(document).on("click", "#btnalerta", function(evt)
    {
        navigator.notification.alert("Mensagem de alerta!",
                                    alertaFechado,
                                     'Alerta',
                                     'Botão'
                                    );
         return false;
    });
    
        /* button  #btnconfirmacao */
    $(document).on("click", "#btnconfirmacao", function(evt)
    {
         navigator.notification.confirm(
             'Escolha uma das opções:',
            onConfirmacao,
            'Confirmar',
            'Sim,Não,Cancelar'
        );
        return false;
    });
    
        /* button  #btnbeepar */
    $(document).on("click", "#btnbeepar", function(evt)
    {
        /* your code goes here */ 
        navigator.notification.beep(3); // quantas vezes beepar
         return false;
    });
    
        /* button  #btnvibrar */
    $(document).on("click", "#btnvibrar", function(evt)
    {
        /* your code goes here */
        navigator.vibrate(3000); // tempo milisegundos
        //navigator.vibrate([3000,1000,2000,1000]);
        return false;
    });
    
    }
    
 document.addEventListener("app.Ready", register_event_handlers, false);
})();


// callback de erro de busca de contatos
function onErroContatos(contatoErro) {
    alert("Erro na busca dos contatos!" + 
          contatoErro.code);
}

function onSucessoContatos(contatos) {
    // limpando a lista
    $("#lstcontatos").html("");
    for (var i = 0; i < contatos.length; i++) {
        // adicionando os itens na lista
        $("#lstcontatos").prepend(
            '<ion-item class="item widget uib_w_6" data-uib="ionic/list_item" data-ver="0">' +  
                contatos[i].displayName + ' - '
                + contatos[i].name.formatted
             +'</ion-item>'        
        );
    }
    return false;
}

function onErroFoto(erroFoto) {
    alert("Erro na captura da foto!"
         + erroFoto);
}

function onSucessoFoto(foto) {
    // exibindo a foto
    $("#imgfoto").attr("src", 
                       "data:image/jpeg;base64," +
                       foto);
}

function alertaFechado() {
    console.log('alerta fechado!');
}

function onConfirmacao(indiceBotao) {
    navigator.notification.alert(
        'Botão clicado: ' + indiceBotao
    );
}
    